select concat(customer_id, ' mail id is ', email_id) as customer_mail_info
from customers;