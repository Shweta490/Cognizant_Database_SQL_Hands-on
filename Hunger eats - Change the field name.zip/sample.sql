ALTER TABLE hotel_details
CHANGE rating hotel_rating INT;